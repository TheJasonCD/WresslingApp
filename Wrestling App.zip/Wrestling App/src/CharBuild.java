public enum CharBuild {
	LITHE, SKINNY, AVERAGE, CURVY, CHUBBY, FAT, OBESE, TONED, MUSCULAR, HERCULEAN;
	
	public String tellType(){
		return this.name();
	}
}
