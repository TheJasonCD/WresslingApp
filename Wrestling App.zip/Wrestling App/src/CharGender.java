public enum CharGender {
	MALE, FEMALE, SHEMALE, HERM, MALE_HERM, CUNTBOY;
	
	public String tellType(){
		return this.name();
	}
}
