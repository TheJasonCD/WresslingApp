
public enum CharSpecies {
	CANINE, FELINE, LAPINE, URSINE, BOVINE, AVIAN, REPTILE;
	
	public String tellType(){
		return this.name();
	}
}
