
public class WrestlingGameDriver {
	GameType gameType;

	public WrestlingGameDriver(GameType game) {
		gameType = game;			
	}
	
}
